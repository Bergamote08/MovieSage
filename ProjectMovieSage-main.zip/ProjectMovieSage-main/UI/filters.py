genres = ['History', 'Action', 'Music', 'TV Movie', 'Thriller', 
                'Drama', 'Science Fiction', 'Animation', 'Adventure', 
                'Family', 'Comedy', 'Mystery', 'Crime', 'War', 'Romance', 
                'Horror', 'Documentary', 'Western', 'Fantasy']

ratings = [i for i in range(11)]

release_date = [i for i in range(1900, 2021, 10)]